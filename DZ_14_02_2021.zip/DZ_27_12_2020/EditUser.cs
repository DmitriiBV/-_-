﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using ChatFormDBLibrary;

namespace DZ_27_12_2020
{
    public partial class EditUser : Form
    {
        private readonly List<TextBox> _boxes;
        public User User { get; set; }
        public EditUser()
        {
            InitializeComponent();
            _boxes = new List<TextBox>() { textBoxName, textBoxSName, textBoxPatronymic, textBoxCountry, textBoxCity, textBoxPhone };
        }
        public EditUser(User user)
        {
            InitializeComponent();
            _boxes = new List<TextBox>() { textBoxName, textBoxSName, textBoxPatronymic, textBoxCountry, textBoxCity, textBoxPhone };
            User = user;
            UnboxingUser(user);
        }
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            ValidateTextBox((TextBox)sender);
            buttonOk.Enabled = _boxes.Select(ValidateTextBox).All(it => it);
        }
        private bool ValidateTextBox(TextBox textBox)
        {
            string pattern = "";
            if (textBox.Tag != null && textBox.Tag.ToString() == "phone")
                pattern = "^[0-9]+$";
            else if (textBox.Tag != null && textBox.Tag.ToString() == "city")
                pattern = "^[А-Яа-я]+[- ]*[А-Яа-я]*$";
            else
                pattern = "^[А-Яа-я]+$";

            var regex = new Regex(pattern);

            if (string.IsNullOrEmpty(textBox.Text))
                return false;
            else if (regex.IsMatch(textBox.Text))
            {
                textBox.ForeColor = Color.Black;
                return true;
            }
            textBox.ForeColor = Color.Red;
            return false;
        }
        private User BoxingUser(User user)
        {
            user.Name = textBoxName.Text;
            user.Surname = textBoxSName.Text;
            user.Patronymic = textBoxPatronymic.Text;
            user.Country = textBoxCountry.Text;
            user.City = textBoxCity.Text;
            user.Telephone = textBoxPhone.Text;
            user.Birthdate = dateTimePickerBirthdate.Value.Date;
            user.Gender = radioButtonMale.Checked == true ? "мужской" : "женский";
            return user;
        }
        private void UnboxingUser(User user)
        {
            textBoxName.Text = user.Name;
            textBoxSName.Text = user.Surname;
            textBoxPatronymic.Text = user.Patronymic;
            textBoxCountry.Text = user.Country;
            textBoxCity.Text = user.City;
            textBoxPhone.Text = user.Telephone;
            dateTimePickerBirthdate.Value = user.Birthdate;

            if (user.Gender == "мужской")
                radioButtonMale.Checked = true;
            else
                radioButtonFemale.Checked = true;
        }
        private void ButtonOk_Click(object sender, EventArgs e)
        {
            if (User == null)
            {
                User = BoxingUser(new User());
            }
            else
                User = BoxingUser(User);       
                        
            DialogResult = DialogResult.OK;
        }
        private void ButtonCancel_Click(object sender, EventArgs e) => DialogResult = DialogResult.Cancel;
    }
}