﻿namespace DZ_27_12_2020
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChatForm));
            this.listBoxUsers = new System.Windows.Forms.ListBox();
            this.listBoxChat = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemDellToMe = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemDellEverywhere = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxMessage = new System.Windows.Forms.TextBox();
            this.labelUsers = new System.Windows.Forms.Label();
            this.labelChat = new System.Windows.Forms.Label();
            this.labelMessage = new System.Windows.Forms.Label();
            this.buttonSendMessage = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonFrontText = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonColorText = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonColorForm = new System.Windows.Forms.ToolStripButton();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.fontDialog = new System.Windows.Forms.FontDialog();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxUsers
            // 
            this.listBoxUsers.FormattingEnabled = true;
            this.listBoxUsers.Location = new System.Drawing.Point(12, 77);
            this.listBoxUsers.Name = "listBoxUsers";
            this.listBoxUsers.Size = new System.Drawing.Size(188, 290);
            this.listBoxUsers.TabIndex = 0;
            this.listBoxUsers.SelectedIndexChanged += new System.EventHandler(this.ListBoxUsers_SelectedIndexChanged);
            // 
            // listBoxChat
            // 
            this.listBoxChat.ContextMenuStrip = this.contextMenuStrip1;
            this.listBoxChat.FormattingEnabled = true;
            this.listBoxChat.Location = new System.Drawing.Point(217, 77);
            this.listBoxChat.Name = "listBoxChat";
            this.listBoxChat.Size = new System.Drawing.Size(571, 290);
            this.listBoxChat.TabIndex = 1;
            this.listBoxChat.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ListBoxChat_MouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemDellToMe,
            this.toolStripMenuItemDellEverywhere});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.ShowCheckMargin = true;
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 48);
            // 
            // toolStripMenuItemDellToMe
            // 
            this.toolStripMenuItemDellToMe.Name = "toolStripMenuItemDellToMe";
            this.toolStripMenuItemDellToMe.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItemDellToMe.Text = "Удалить у меня";
            this.toolStripMenuItemDellToMe.Click += new System.EventHandler(this.ToolStripMenuItemDellToMe_Click);
            // 
            // toolStripMenuItemDellEverywhere
            // 
            this.toolStripMenuItemDellEverywhere.Name = "toolStripMenuItemDellEverywhere";
            this.toolStripMenuItemDellEverywhere.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItemDellEverywhere.Text = "Удалить везде";
            this.toolStripMenuItemDellEverywhere.Click += new System.EventHandler(this.ToolStripMenuItemDellEverywhere_Click);
            // 
            // textBoxMessage
            // 
            this.textBoxMessage.Location = new System.Drawing.Point(12, 395);
            this.textBoxMessage.Multiline = true;
            this.textBoxMessage.Name = "textBoxMessage";
            this.textBoxMessage.Size = new System.Drawing.Size(644, 43);
            this.textBoxMessage.TabIndex = 2;
            // 
            // labelUsers
            // 
            this.labelUsers.AutoSize = true;
            this.labelUsers.Location = new System.Drawing.Point(9, 61);
            this.labelUsers.Name = "labelUsers";
            this.labelUsers.Size = new System.Drawing.Size(80, 13);
            this.labelUsers.TabIndex = 3;
            this.labelUsers.Text = "Пользователи";
            // 
            // labelChat
            // 
            this.labelChat.AutoSize = true;
            this.labelChat.Location = new System.Drawing.Point(214, 61);
            this.labelChat.Name = "labelChat";
            this.labelChat.Size = new System.Drawing.Size(26, 13);
            this.labelChat.TabIndex = 4;
            this.labelChat.Text = "Чат";
            // 
            // labelMessage
            // 
            this.labelMessage.AutoSize = true;
            this.labelMessage.Location = new System.Drawing.Point(12, 379);
            this.labelMessage.Name = "labelMessage";
            this.labelMessage.Size = new System.Drawing.Size(93, 13);
            this.labelMessage.TabIndex = 5;
            this.labelMessage.Text = "Сообщение в чат";
            // 
            // buttonSendMessage
            // 
            this.buttonSendMessage.Location = new System.Drawing.Point(662, 395);
            this.buttonSendMessage.Name = "buttonSendMessage";
            this.buttonSendMessage.Size = new System.Drawing.Size(126, 43);
            this.buttonSendMessage.TabIndex = 6;
            this.buttonSendMessage.Text = "Отправить сообщение";
            this.buttonSendMessage.UseVisualStyleBackColor = true;
            this.buttonSendMessage.Click += new System.EventHandler(this.ButtonSendMessage_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cutToolStripMenuItem.Text = "&Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.CutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.copyToolStripMenuItem.Text = "C&opy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.CopyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.PasteToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorTextToolStripMenuItem,
            this.backColorToolStripMenuItem,
            this.frontToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "&View";
            // 
            // colorTextToolStripMenuItem
            // 
            this.colorTextToolStripMenuItem.Name = "colorTextToolStripMenuItem";
            this.colorTextToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colorTextToolStripMenuItem.Text = "&Color text";
            this.colorTextToolStripMenuItem.Click += new System.EventHandler(this.ColorTextToolStripMenuItem_Click);
            // 
            // backColorToolStripMenuItem
            // 
            this.backColorToolStripMenuItem.Name = "backColorToolStripMenuItem";
            this.backColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.backColorToolStripMenuItem.Text = "&Back color";
            this.backColorToolStripMenuItem.Click += new System.EventHandler(this.BackColorToolStripMenuItem_Click);
            // 
            // frontToolStripMenuItem
            // 
            this.frontToolStripMenuItem.Name = "frontToolStripMenuItem";
            this.frontToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.frontToolStripMenuItem.Text = "&Front";
            this.frontToolStripMenuItem.Click += new System.EventHandler(this.FrontToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonFrontText,
            this.toolStripButtonColorText,
            this.toolStripButtonColorForm});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 8;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonFrontText
            // 
            this.toolStripButtonFrontText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonFrontText.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonFrontText.Image")));
            this.toolStripButtonFrontText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonFrontText.Name = "toolStripButtonFrontText";
            this.toolStripButtonFrontText.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonFrontText.Text = "Шрифт";
            this.toolStripButtonFrontText.Click += new System.EventHandler(this.ToolStripButtonFrontText_Click);
            // 
            // toolStripButtonColorText
            // 
            this.toolStripButtonColorText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonColorText.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonColorText.Image")));
            this.toolStripButtonColorText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColorText.Name = "toolStripButtonColorText";
            this.toolStripButtonColorText.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonColorText.Text = "Цвет текста";
            this.toolStripButtonColorText.Click += new System.EventHandler(this.ToolStripButtonColorText_Click);
            // 
            // toolStripButtonColorForm
            // 
            this.toolStripButtonColorForm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonColorForm.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonColorForm.Image")));
            this.toolStripButtonColorForm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColorForm.Name = "toolStripButtonColorForm";
            this.toolStripButtonColorForm.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonColorForm.Text = "Заливка формы";
            this.toolStripButtonColorForm.Click += new System.EventHandler(this.ToolStripButtonColorForm_Click);
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.buttonSendMessage);
            this.Controls.Add(this.labelMessage);
            this.Controls.Add(this.labelChat);
            this.Controls.Add(this.labelUsers);
            this.Controls.Add(this.textBoxMessage);
            this.Controls.Add(this.listBoxChat);
            this.Controls.Add(this.listBoxUsers);
            this.Name = "ChatForm";
            this.Text = "ChatForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChatForm_FormClosing);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxUsers;
        private System.Windows.Forms.ListBox listBoxChat;
        private System.Windows.Forms.TextBox textBoxMessage;
        private System.Windows.Forms.Label labelUsers;
        private System.Windows.Forms.Label labelChat;
        private System.Windows.Forms.Label labelMessage;
        private System.Windows.Forms.Button buttonSendMessage;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemDellToMe;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemDellEverywhere;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frontToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonFrontText;
        private System.Windows.Forms.ToolStripButton toolStripButtonColorText;
        private System.Windows.Forms.ToolStripButton toolStripButtonColorForm;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.FontDialog fontDialog;
    }
}