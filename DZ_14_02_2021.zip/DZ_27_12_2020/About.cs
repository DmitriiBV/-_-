﻿using System;
using System.Windows.Forms;

namespace DZ_27_12_2020
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
            Text = "О программе Form";
            ShowAbout();
        }
        private void ShowAbout() => textBoxAbout.Text = "Текст о программе Form...";
        private void ButtonOk_Click(object sender, EventArgs e) => DialogResult = DialogResult.OK;
    }
}
