﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using ChatFormDBLibrary;
using Message = ChatFormDBLibrary.Message;

namespace DZ_27_12_2020
{
    public partial class MainForm : Form
    {
        private readonly List<ChatForm> _chatForms = new List<ChatForm>();
        private User SelectedUser { get; set; }
        public List<User> UsersInChat => _chatForms.Select(it => it.User).ToList();            
        public MainForm()
        {
            InitializeComponent();
            LoadMessageToLog();
        }
        private void LoadMessageToLog()
        {            
            foreach (var item in ChatFormDB.GetAllMessages())
            {                
                if (item.IdReceiver == null)
                    ShowLog($"{item.DateCreate} пользователь: {item.UserSender} {item.Text}");
                else
                    ShowLog($"{item.DateCreate} отправитель: {item.UserSender} текст: {item.Text} получатель: {item.UserReceiver}" + $"{Environment.NewLine}");
            }
        }
        private void SelectUser()
        {
            if (SelectedUser != null)
                labelSelectUser.Text = SelectedUser.ToString();
            else
                labelSelectUser.Text = "Пользователь не выбран";
        }
        private void ButtonSelectUser_Click(object sender, EventArgs e)
        {         
            var listUserForm = new ListUserForm();
            if (listUserForm.ShowDialog() == DialogResult.OK)
            {
                SelectedUser = listUserForm.SelectedUser;
                SelectUser();
            }
            else
                return;
        }
        private void ShowLog(string str) => listBoxLog.Items.Add(str);
        private void ButtonBeginChat_Click(object sender, EventArgs e)
        {
            if (_chatForms.Any(it => it.User.ToString() == SelectedUser.ToString()))
            {
                MessageBox.Show("Этот пользователь уже зашел в чат", "Сообщение", MessageBoxButtons.OK);
                return;
            }
            if (SelectedUser == null)
            {
                MessageBox.Show("Пользователь не выбран", "Сообщение", MessageBoxButtons.OK);
                return;
            }
            var chatForm = new ChatForm(this, SelectedUser);
            _chatForms.Add(chatForm);            
            AddChatForm(SelectedUser);
            chatForm.Show();
            SelectedUser = null;
            SelectUser();            
        }
        public void UpdateChatForms()
        {
            foreach (var item in _chatForms)
            {
                item.UpdateListBoxChat();
            }
        }
        private void AddAndSaveMessageToList(Message message)
        {
            ChatFormDB.AddMessage(message);     
        }
        private void AddChatForm(User user)
        {
            labelNumber.Text = _chatForms.Count.ToString();           
            var message = new Message() { DateCreate = DateTime.Now, IdSender = user.Id, Text = "зашел в чат"};
            AddAndSaveMessageToList(message);            
            ShowLog($"{message.DateCreate} пользователь: {message.UserSender} {message.Text}");          
            _chatForms.Where(it => it.User.Id != SelectedUser.Id).ToList().ForEach(it => it.Accept($"{message.DateCreate} пользователь: {message.UserSender} {message.Text}"));
            _chatForms.ForEach(it => it.UpdateListBoxUsersForm());
        }
        public void CloseChatForm(User user)
        {            
            _chatForms.Remove(_chatForms.First(it => it.User.ToString() == user.ToString()));                   
            var message = new Message() { DateCreate = DateTime.Now, IdSender = user.Id, Text = "вышел из чата" };
            AddAndSaveMessageToList(message);
            ShowLog($"{message.DateCreate} пользователь: {message.UserSender} {message.Text}");
            _chatForms.ForEach(it => it.Accept($"{message.DateCreate} пользователь: {message.UserSender} {message.Text}"));
            _chatForms.ForEach(it => it.UpdateListBoxUsersForm());
            labelNumber.Text = _chatForms.Count.ToString();
        }
        public void SentMessage(Message message)
        {
            AddAndSaveMessageToList(message);
            ShowLog($"{message.DateCreate} отправитель: {message.UserSender} текст: {message.Text} получатель: {message.UserReceiver}" + $"{Environment.NewLine}");           
            _chatForms.Where(it => it.User.ToString() == message.UserReceiver.ToString()).ToList().ForEach(
                it => it.Accept($"{message.DateCreate} {message.UserSender} пишет: {message.Text}" + $"{Environment.NewLine}"));
            _chatForms.Where(it => it.User.ToString() == message.UserSender.ToString()).ToList().ForEach(
                it => it.Accept($"{message.DateCreate} Вы: {message.Text}" + $"{Environment.NewLine}"));
        }
        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var about = new About();
            about.ShowDialog();
        }
        private void CloseToolStripMenuItem1_Click(object sender, EventArgs e) => Close();
    }
}