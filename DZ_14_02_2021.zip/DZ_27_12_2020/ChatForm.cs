﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using ChatFormDBLibrary;
using Message = ChatFormDBLibrary.Message;

namespace DZ_27_12_2020
{
    public partial class ChatForm : Form
    {
        private readonly MainForm _mainForm;
        private readonly User _user;   
        private string _bufferText;
        private List<Message> _userMessages;
        public User User => _user;        
        public ChatForm(MainForm mainForm, User user)
        {
            _userMessages = new List<Message>();
            this._mainForm = mainForm;
            this._user = user;            
            InitializeComponent();
            Text += $" - [Пользователь: {user}]";
            LoadingAndUpdatingFormViewSettings();
        }
        private void LoadingAndUpdatingFormViewSettings()
        {
            if (!ChatFormDB.GetAllViewForms().Exists(it => it.IdUser == User.Id))
            {
                ViewForm viewForm = new ViewForm()
                {
                    IdUser = User.Id,
                    FontTextName = Font.Name,
                    FontTextSize = Font.Size,
                    FontTextBold = Font.Bold,
                    FontTextItalic = Font.Italic,
                    FontTextUnderline = Font.Underline,
                    FontTextStrikeout = Font.Strikeout,
                    ColorText = listBoxChat.ForeColor.ToArgb(),
                    ColorForm = BackColor.ToArgb()
                };
                ChatFormDB.AddViewForm(viewForm);                
            }          
            foreach (var item in ChatFormDB.GetAllViewForms())
            {
                if (item.IdUser == User.Id)
                {
                    listBoxChat.ForeColor = Color.FromArgb((int)item.ColorText);
                    BackColor = Color.FromArgb((int)item.ColorForm);

                    FontStyle fontStyle = FontStyle.Regular;
                    if ((bool)item.FontTextBold)
                        fontStyle |= FontStyle.Bold;
                    if ((bool)item.FontTextItalic)
                        fontStyle |= FontStyle.Italic;
                    if ((bool)item.FontTextUnderline)
                        fontStyle |= FontStyle.Underline;
                    if ((bool)item.FontTextStrikeout)
                        fontStyle |= FontStyle.Strikeout;

                    Font font = new Font(item.FontTextName, (float)item.FontTextSize, fontStyle);
                    listBoxChat.Font = font;
                }
            }
        }
        public void UpdateListBoxUsersForm()
        {           
            listBoxUsers.Items.Clear();
            _mainForm.UsersInChat.Where(it => it.Id != User.Id).ToList().ForEach(it => listBoxUsers.Items.Add(it));
        }
        public void Accept(string message) => listBoxChat.Items.Add(message);
        private void ButtonSendMessage_Click(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedItem == null)
                return;
            var message = new Message()
            {
                IdReceiver = ((User)listBoxUsers.SelectedItem).Id,
                DateCreate = DateTime.Now,
                IdSender = _user.Id,
                Text = textBoxMessage.Text
            };
            _mainForm.SentMessage(message);
            _userMessages.Add(message);
            textBoxMessage.Text = "";
        }
        private void ChatForm_FormClosing(object sender, FormClosingEventArgs e) => _mainForm.CloseChatForm(User);
        private void ListBoxChat_MouseUp(object sender, MouseEventArgs e)
        {
            listBoxChat.ContextMenuStrip.Visible = false;
            if (e.Button == MouseButtons.Right)
            {
                listBoxChat.SelectedIndex = listBoxChat.IndexFromPoint(e.Location);
                if (listBoxChat.SelectedIndex != -1)
                    listBoxChat.ContextMenuStrip.Visible = true;
            }
        }
        private void MessageDellToMe()
        {
            if (listBoxChat.SelectedItem != null && _userMessages.Count != 0)  
            {
                var idMessage = (_userMessages.ElementAt(listBoxChat.Items.IndexOf(listBoxChat.SelectedItem))).Id;
                Message message = ChatFormDB.GetAllMessages().FirstOrDefault(it => it.Id == idMessage);
                message.IdDelete = User.Id;
                ChatFormDB.EditMessage(message);
                for (int i = 0; i < listBoxChat.SelectedItems.Count; i++)
                {
                    listBoxChat.Items.Remove(listBoxChat.SelectedItems[i]);
                }               
            }
        }
        private void ToolStripMenuItemDellToMe_Click(object sender, EventArgs e) => MessageDellToMe();
        private void ToolStripMenuItemDellEverywhere_Click(object sender, EventArgs e)
        {
            if (listBoxChat.SelectedItem != null && _userMessages.Count != 0)
            {
                var idMessage = (_userMessages.ElementAt(listBoxChat.Items.IndexOf(listBoxChat.SelectedItem))).Id;
                Message message = ChatFormDB.GetAllMessages().FirstOrDefault(it => it.Id == idMessage);
                message.DeleteEverywhere = true;
                ChatFormDB.EditMessage(message);
                MessageDellToMe();
                _mainForm.UpdateChatForms();
            }
        }
        public void UpdateListBoxChat()
        {
            if (listBoxUsers.SelectedItem != null)
            {
                listBoxChat.Items.Clear();
                _userMessages.Clear();
                var idUser = ((User)listBoxUsers.SelectedItem).Id;   
                foreach (var item in ChatFormDB.GetAllMessages())
                {
                    if (item.IdSender == idUser && item.IdReceiver == _user.Id && item.IdDelete != _user.Id && item.DeleteEverywhere == null)
                    {
                        listBoxChat.Items.Add($"{item.DateCreate} {item.UserSender} пишет: {item.Text}" + $"{Environment.NewLine}");
                        _userMessages.Add(item);
                    }
                    if (item.IdReceiver == idUser && item.IdSender == _user.Id && item.IdDelete != _user.Id && item.DeleteEverywhere == null)
                    {
                        listBoxChat.Items.Add($"{item.DateCreate} Вы: {item.Text}" + $"{Environment.NewLine}");
                        _userMessages.Add(item);
                    }
                }
            }
        }
        private void ListBoxUsers_SelectedIndexChanged(object sender, EventArgs e) => UpdateListBoxChat();
        private void MessageColorText()
        {
            colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {                
                listBoxChat.ForeColor = colorDialog.Color;
                ViewForm viewForm = ChatFormDB.GetAllViewForms().FirstOrDefault(it => it.IdUser == User.Id);
                viewForm.ColorText = colorDialog.Color.ToArgb();
                ChatFormDB.EditViewForm(viewForm);                
            }
        }
        private void BackColorForm()
        {
            colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                BackColor = colorDialog.Color;
                ViewForm viewForm = ChatFormDB.GetAllViewForms().FirstOrDefault(it => it.IdUser == User.Id);
                viewForm.ColorForm = colorDialog.Color.ToArgb();
                ChatFormDB.EditViewForm(viewForm);
            }
        }
        private void MessageFrontText()
        {
            fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                listBoxChat.Font = fontDialog.Font;
                ViewForm viewForm = ChatFormDB.GetAllViewForms().FirstOrDefault(it => it.IdUser == User.Id);
                viewForm.FontTextName = fontDialog.Font.Name;
                viewForm.FontTextSize = fontDialog.Font.Size;
                viewForm.FontTextBold = fontDialog.Font.Bold;
                viewForm.FontTextItalic = fontDialog.Font.Italic;
                viewForm.FontTextUnderline = fontDialog.Font.Underline;
                viewForm.FontTextStrikeout = fontDialog.Font.Strikeout;
                ChatFormDB.EditViewForm(viewForm);
            }
        }
        private void ToolStripButtonColorText_Click(object sender, EventArgs e) => MessageColorText();
        private void ToolStripButtonColorForm_Click(object sender, EventArgs e) => BackColorForm();
        private void ToolStripButtonFrontText_Click(object sender, EventArgs e) => MessageFrontText();
        private void ColorTextToolStripMenuItem_Click(object sender, EventArgs e) => MessageColorText();
        private void BackColorToolStripMenuItem_Click(object sender, EventArgs e) => BackColorForm();
        private void FrontToolStripMenuItem_Click(object sender, EventArgs e) => MessageFrontText();
        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _bufferText = "";
            if (listBoxChat.SelectedItem != null && _userMessages.Count != 0)
            {
                var idMessage = (_userMessages.ElementAt(listBoxChat.Items.IndexOf(listBoxChat.SelectedItem))).Id;               
                ChatFormDB.GetAllMessages().Where(it => it.Id == idMessage).ToList().ForEach(it => _bufferText = it.Text);
                MessageDellToMe();
            }
        }
        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _bufferText = "";
            if (listBoxChat.SelectedItem != null && _userMessages.Count != 0)
            {
                var idMessage = (_userMessages.ElementAt(listBoxChat.Items.IndexOf(listBoxChat.SelectedItem))).Id;               
                ChatFormDB.GetAllMessages().Where(it => it.Id == idMessage).ToList().ForEach(it => _bufferText = it.Text);
                listBoxChat.SelectedItem = null;
            }
        }
        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(_bufferText!=null&& _bufferText!="")
                textBoxMessage.Text = _bufferText;
        }
    }
}