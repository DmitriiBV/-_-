﻿using System;
using System.Windows.Forms;
using ChatFormDBLibrary;

namespace DZ_27_12_2020
{
    public partial class ListUserForm : Form
    {
        public User SelectedUser => listBoxUsers.SelectedItem as User;
        public ListUserForm()
        {
            InitializeComponent();            
            UpdateListBox();
        }
        private void UpdateListBox()
        {
            listBoxUsers.Items.Clear();
            ChatFormDB.GetAllUsers().ForEach(it => listBoxUsers.Items.Add(it));            
        }
        private void AddUserToList()
        {
            var editUser = new EditUser();
            if (editUser.ShowDialog() == DialogResult.OK)
            {
                ChatFormDB.AddUser(editUser.User);                
                listBoxUsers.SelectedItem = null;
                UpdateListBox();
            }
            else
                return;
        }
        private void EditUserToList()
        {
            if (listBoxUsers.SelectedItem != null)
            {
                var editUser = new EditUser((User)listBoxUsers.SelectedItem);
                if (editUser.ShowDialog() == DialogResult.OK)
                {
                    ChatFormDB.EditUser(editUser.User);                    
                    listBoxUsers.SelectedItem = null;
                    UpdateListBox();
                }
                else
                    return;
            }
        }
        private void DeleteUserToList()
        {
            if (listBoxUsers.SelectedItem != null)
            {
                ChatFormDB.DeleteUser((User)listBoxUsers.SelectedItem);
                listBoxUsers.SelectedItem = null;
                UpdateListBox();                            
            }
        }
        private void ButtonAddUser_Click(object sender, EventArgs e) => AddUserToList();
        private void ButtonUpdateUser_Click(object sender, EventArgs e) => EditUserToList();
        private void ButtonDeleteUser_Click(object sender, EventArgs e) => DeleteUserToList();      
        private void ListBoxUsers_SelectedValueChanged(object sender, EventArgs e)
        {
            var userData = "";
            if (listBoxUsers.SelectedItem != null)
            {                
                var user = (User)listBoxUsers.SelectedItem;
                userData += $"Фамилия: {user.Surname}" + $"{Environment.NewLine}";
                userData += $"Имя: {user.Name}" + $"{Environment.NewLine}";
                userData += $"Отчество: {user.Patronymic}" + $"{Environment.NewLine}";
                userData += $"Страна: {user.Country}" + $"{Environment.NewLine}";
                userData += $"Город: {user.City}" + $"{Environment.NewLine}";
                userData += $"Телефон: {user.Telephone}" + $"{Environment.NewLine}";
                userData += $"Дата рождения: {user.Birthdate.ToLongDateString()}" + $"{Environment.NewLine}";
                userData += $"Пол: {user.Gender}" + $"{Environment.NewLine}";
                textBoxUserData.Text = userData;
            }
            else
                textBoxUserData.Text = userData;
        }
        private void ButtonSelectUser_Click(object sender, EventArgs e) => DialogResult = listBoxUsers.SelectedItem != null ? DialogResult.OK : DialogResult;     
        private void ButtonCancel_Click(object sender, EventArgs e) => DialogResult = DialogResult.Cancel;
    }
}