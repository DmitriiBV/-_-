﻿namespace ChatFormDBLibrary
{
    public partial class User
    {
        public override string ToString() => $"{Surname} {Name} {Patronymic}";
    }
}
